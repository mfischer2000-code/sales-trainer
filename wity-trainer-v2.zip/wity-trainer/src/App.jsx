import { useState, useRef, useEffect } from "react";

const PERSONAS = [
  {
    id: "pharma-zuerich",
    name: "Thomas Brunner",
    role: "IT-Leiter",
    company: "Pharmatech AG, Zürich",
    industry: "Pharma",
    difficulty: "Mittel",
    diffColor: "#FF8F00",
    context: "Mittelständisches Pharmaunternehmen, 1.200 Mitarbeiter. Mitten in der S/4HANA-Migration (Go-Live Q3 2026). Nutzt aktuell einen Mix aus altem SEEBURGER EDI On-Premise und manuelle CSV-Uploads. Hauptsorge: Die EDI-Schnittstellen könnten bei der Migration brechen. Budget ist genehmigt für die S/4HANA-Migration, aber Integration war im Scope 'vergessen' worden.",
    personality: "Offen und fachlich versiert, aber skeptisch gegenüber neuen Anbietern. Will Beweise und Referenzen aus der Pharma-Branche. Redet gerne über technische Details. Wird ungeduldig, wenn der Seller zu früh pitcht, ohne das Problem verstanden zu haben. Schweizer Mentalität: höflich, aber direkt wenn es um Substanz geht.",
    hiddenPain: "Sein Chef (COO) hat ihn persönlich für die pünktliche S/4HANA-Migration verantwortlich gemacht. Wenn die Integration die Migration verzögert, steht sein Bonus und möglicherweise seine Position auf dem Spiel. Er schläft schlecht deswegen, würde das aber nie von sich aus erzählen.",
    triggers: ["S/4HANA-Migration", "EDI-Integration", "Pharma-Compliance", "GxP-Validierung"]
  },
  {
    id: "retail-romandie",
    name: "Marie-Claire Dupont",
    role: "CIO",
    company: "Groupe Alpin Retail, Lausanne",
    industry: "Retail",
    difficulty: "Schwer",
    diffColor: "#D32F2F",
    context: "Großer Schweizer Retailer mit 45 Filialen, Online-Shop und komplexer Lieferkette. Nutzt MuleSoft für APIs, einen alten EDI-Provider für Lieferanten-EDI, und SEEBURGER für einen kleinen Teil der B2B-Integration. Drei verschiedene Integrationstools, drei verschiedene Teams, drei verschiedene Budgets. Total überfordert.",
    personality: "Extrem wenig Zeit. Redet schnell, will auf den Punkt kommen. Hasst PowerPoint-Präsentationen und Feature-Listen. Will wissen: Was löst ihr KONKRET und bis WANN? Spricht Französisch und Deutsch, bevorzugt aber Deutsch im Business-Kontext. Wird sofort abschalten, wenn der Seller generisch wird.",
    hiddenPain: "Der Verwaltungsrat hat ein Digitalisierungsprogramm verabschiedet mit klaren KPIs. Sie muss die Integrationskosten bis Ende 2026 um 30% senken – bei gleichzeitig steigender Komplexität (neuer Online-Marktplatz). Wenn sie das nicht schafft, wird ein externer Berater geholt.",
    triggers: ["Tool-Konsolidierung", "Kostenreduktion", "Multi-Channel-Integration", "Lieferketten-EDI"]
  },
  {
    id: "automotive-sc",
    name: "Andreas Keller",
    role: "Head of Supply Chain",
    company: "PrecisionMotion AG, Winterthur",
    industry: "Automotive / Maschinenbau",
    difficulty: "Mittel",
    diffColor: "#FF8F00",
    context: "Tier-1 Automotive-Zulieferer mit 4 Werken (CH, DE, CZ, MX). Nach einer Akquisition vor 18 Monaten gibt es jetzt 4 verschiedene EDI-Systeme. Jedes Werk hat eigene Prozesse, eigene Formate, eigene Ansprechpartner bei OEMs. SEEBURGER wird in 2 der 4 Werke bereits eingesetzt.",
    personality: "Zahlenmensch. Will ROI, Payback-Period, TCO-Vergleiche. Technisch nicht tief, aber versteht Business-Prozesse perfekt. Fragt immer 'Was kostet mich das?' und 'Was spare ich damit?'. Respektiert Seller, die seine Welt verstehen (Automotive-EDI, VDA, EDIFACT, JIT/JIS).",
    hiddenPain: "Die OEMs (BMW, Stellantis) drohen mit Strafzahlungen wegen verspäteter ASN-Meldungen aus den neuen Werken. Letztes Quartal: CHF 340K Konventionalstrafen. Der CEO hat das Thema zur Chefsache erklärt. Andreas muss bis Q2 2026 eine Lösung vorweisen.",
    triggers: ["EDI-Konsolidierung", "M&A-Integration", "OEM-Compliance", "Multi-Plant"]
  },
  {
    id: "kmu-cfo",
    name: "Beat Zimmermann",
    role: "CFO & Mitglied der Geschäftsleitung",
    company: "Helvetia Mechanik GmbH, Solothurn",
    industry: "Maschinenbau KMU",
    difficulty: "Schwer",
    diffColor: "#D32F2F",
    context: "Traditionelles Schweizer KMU, 180 Mitarbeiter, fertigt Präzisionsteile für Medtech und Uhrenindustrie. Kein dedizierter IT-Leiter – IT wird vom CFO mitverantwortet. Nutzt SAP Business One (nicht S/4HANA). Integration? 'Machen wir mit Excel und E-Mail.' Hört den Begriff 'iPaaS' zum ersten Mal.",
    personality: "Bodenständig, sparsam, skeptisch. Denkt in Franken und Rappen. Versteht nichts von IT-Fachbegriffen und wird grantig, wenn man ihn mit Buzzwords überschüttet. Will wissen: 'Was bringt mir das unterm Strich?' Vertraut auf Empfehlungen von anderen KMU-Unternehmern, nicht auf Hochglanz-Präsentationen.",
    hiddenPain: "Sein größter Kunde (Medtech, 35% des Umsatzes) hat angekündigt, ab 2027 nur noch EDI-basierte Bestellungen zu akzeptieren. Wenn Helvetia Mechanik das nicht hinbekommt, verliert er seinen wichtigsten Kunden. Er hat keine Ahnung, was er tun soll, und schämt sich ein bisschen dafür.",
    triggers: ["Kundenforderung-EDI", "KMU-Digitalisierung", "Einfachheit", "Kosteneffizienz"]
  }
];

const SYSTEM_PROMPT_BASE = `Du bist ein Schweizer Geschäftsentscheider in einem Rollenspiel-Training für B2B-Vertriebsmitarbeiter von SEEBURGER (einem Anbieter für Integration, EDI, API-Management und iPaaS-Lösungen).

DEINE AUFGABE:
- Du spielst die angegebene Persona REALISTISCH
- Du verhältst dich wie ein echter Schweizer Geschäftskunde: höflich, aber direkt, wertschätzend aber anspruchsvoll
- Du gibst Informationen nur preis, wenn der Seller die richtigen Fragen stellt
- Du wirst UNGEDULDIG wenn der Seller zu früh pitcht, ohne dein Problem zu verstehen
- Du wirst SKEPTISCH bei generischen Aussagen ohne Substanz
- Du ÖFFNEST DICH bei guten, empathischen Fragen, die zeigen, dass der Seller deine Welt versteht
- Deinen "Hidden Pain" teilst du NICHT von dir aus – nur wenn der Seller geschickt genug fragt (z.B. persönliche Auswirkungen, Zeitdruck, Konsequenzen)
- Du sprichst Schweizer Hochdeutsch (kein Dialekt, aber Schweizer Ausdrücke wie "Grüezi", "genau", gelegentliches "oder?" am Satzende)
- Deine Antworten sind 2-4 Sätze lang, wie in einem echten Gespräch

WICHTIG:
- Sei KEIN einfacher Gesprächspartner. Ein guter Seller muss arbeiten.
- Wenn der Seller nur Features aufzählt, sage höflich: "Das klingt ja alles schön, aber was hat das konkret mit meiner Situation zu tun?"
- Wenn der Seller gute Discovery-Fragen stellt, belohne ihn mit echten Informationen
- Antworte IMMER auf Deutsch
- Halte dich an deine Persona – improvisiere nicht über die gegebenen Fakten hinaus

GESPRÄCHSSTART: Du nimmst einen Anruf oder ein Meeting an. Der Seller hat über einen gemeinsamen Kontakt oder eine Veranstaltung den Termin bekommen. Begrüße ihn höflich aber geschäftsmäßig.`;

const FEEDBACK_PROMPT = `Du bist ein erfahrener B2B-Sales-Coach, der gerade ein WITY-Discovery-Gespräch zwischen einem SEEBURGER-Vertriebsmitarbeiter und einem simulierten Schweizer Kunden ausgewertet hat.

Analysiere das Gespräch und gib strukturiertes Feedback. Bewerte auf einer Skala von 1-5 (1=nicht vorhanden, 5=exzellent) und gib KONKRETE Beispiele aus dem Gespräch.

Antworte NUR mit einem JSON-Objekt in genau diesem Format (keine Markdown-Backticks, kein anderer Text):
{
  "gesamtnote": <1-5>,
  "zusammenfassung": "<2-3 Sätze Gesamteindruck>",
  "kategorien": [
    {
      "name": "Öffnung & Rapport",
      "score": <1-5>,
      "feedback": "<Was war gut, was kann besser>",
      "beispiel": "<Konkretes Zitat oder Moment aus dem Gespräch>"
    },
    {
      "name": "Pain Discovery",
      "score": <1-5>,
      "feedback": "<Wurde der Pain auf allen 4 Ebenen erforscht?>",
      "beispiel": "<Konkretes Zitat>"
    },
    {
      "name": "Fragetechnik",
      "score": <1-5>,
      "feedback": "<Offene vs. geschlossene Fragen, Tiefe des Nachfragens>",
      "beispiel": "<Konkretes Zitat>"
    },
    {
      "name": "WITY-Haltung",
      "score": <1-5>,
      "feedback": "<Wurde zugehört oder zu früh gepitcht? Echtes Interesse?>",
      "beispiel": "<Konkretes Zitat>"
    },
    {
      "name": "Business Impact",
      "score": <1-5>,
      "feedback": "<Wurde der messbare Geschäftsschaden herausgearbeitet?>",
      "beispiel": "<Konkretes Zitat>"
    },
    {
      "name": "Nächster Schritt",
      "score": <1-5>,
      "feedback": "<Wurde ein konkreter Next Step vereinbart?>",
      "beispiel": "<Konkretes Zitat>"
    }
  ],
  "topTipp": "<Der EINE wichtigste Verbesserungsvorschlag für diesen Seller>",
  "hiddenPainEntdeckt": <true/false>,
  "hiddenPainKommentar": "<Wurde der persönliche Pain des Entscheiders aufgedeckt? Wie?>"
}`;

function ScoreBar({ score, max = 5 }) {
  const pct = (score / max) * 100;
  const color = score >= 4 ? "#2E7D32" : score >= 3 ? "#FF8F00" : "#D32F2F";
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
      <div style={{ flex: 1, height: 8, background: "#E8E8E8", borderRadius: 4, overflow: "hidden" }}>
        <div style={{ width: `${pct}%`, height: "100%", background: color, borderRadius: 4, transition: "width 0.6s ease" }} />
      </div>
      <span style={{ fontWeight: 700, color, fontSize: 15, minWidth: 28, textAlign: "right", fontFamily: "'DM Mono', monospace" }}>{score}/5</span>
    </div>
  );
}

export default function WITYTrainer() {
  const [screen, setScreen] = useState("select");
  const [persona, setPersona] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState(null);
  const [feedbackLoading, setFeedbackLoading] = useState(false);
  const [turnCount, setTurnCount] = useState(0);
  const [error, setError] = useState(null);
  const chatEndRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  useEffect(() => {
    if (screen === "chat") inputRef.current?.focus();
  }, [screen, loading]);

  async function startConversation(p) {
    setPersona(p);
    setMessages([]);
    setTurnCount(0);
    setFeedback(null);
    setError(null);
    setScreen("chat");
    setLoading(true);

    try {
      const res = await fetch("/api/claude", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          system: `${SYSTEM_PROMPT_BASE}\n\nDEINE PERSONA:\nName: ${p.name}\nRolle: ${p.role}\nUnternehmen: ${p.company}\nBranche: ${p.industry}\nKontext: ${p.context}\nPersönlichkeit: ${p.personality}\nHidden Pain (nur preisgeben wenn Seller sehr gut fragt): ${p.hiddenPain}\nRelevante Trigger-Themen: ${p.triggers.join(", ")}`,
          messages: [{ role: "user", content: "Das Gespräch beginnt. Du bist der Kunde. Begrüße den Seller, der gerade zu einem vereinbarten 30-Minuten-Termin erscheint. Stelle dich kurz vor und frage, was der Anlass des Gesprächs ist. Halte dich kurz (2-3 Sätze)." }]
        })
      });
      const data = await res.json();
      const text = data.content?.map(c => c.text || "").join("") || "Grüezi.";
      setMessages([{ role: "persona", text }]);
    } catch (e) {
      setError("Verbindungsfehler. Bitte prüfe deine Internetverbindung.");
    }
    setLoading(false);
  }

  async function sendMessage() {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput("");
    const newMessages = [...messages, { role: "seller", text: userMsg }];
    setMessages(newMessages);
    setTurnCount(t => t + 1);
    setLoading(true);

    try {
      const apiMessages = [];
      apiMessages.push({ role: "user", content: "Das Gespräch beginnt. Du bist der Kunde. Begrüße den Seller kurz." });
      apiMessages.push({ role: "assistant", content: newMessages[0].text });
      for (let i = 1; i < newMessages.length; i++) {
        apiMessages.push({
          role: newMessages[i].role === "seller" ? "user" : "assistant",
          content: newMessages[i].text
        });
      }

      const res = await fetch("/api/claude", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          system: `${SYSTEM_PROMPT_BASE}\n\nDEINE PERSONA:\nName: ${persona.name}\nRolle: ${persona.role}\nUnternehmen: ${persona.company}\nBranche: ${persona.industry}\nKontext: ${persona.context}\nPersönlichkeit: ${persona.personality}\nHidden Pain (nur preisgeben wenn Seller sehr gut fragt): ${persona.hiddenPain}\nRelevante Trigger-Themen: ${persona.triggers.join(", ")}\n\nDas Gespräch läuft seit ${turnCount + 1} Runden.${turnCount >= 8 ? " Das Gespräch nähert sich dem Ende. Wenn der Seller keinen konkreten nächsten Schritt vorschlägt, weise höflich darauf hin, dass du gleich in ein anderes Meeting musst." : ""}`,
          messages: apiMessages
        })
      });
      const data = await res.json();
      const text = data.content?.map(c => c.text || "").join("") || "...";
      setMessages([...newMessages, { role: "persona", text }]);
    } catch (e) {
      setError("Verbindungsfehler beim Senden.");
    }
    setLoading(false);
  }

  async function requestFeedback() {
    setFeedbackLoading(true);
    setScreen("feedback");

    const transcript = messages.map(m =>
      m.role === "seller" ? `SELLER: ${m.text}` : `KUNDE (${persona.name}): ${m.text}`
    ).join("\n\n");

    try {
      const res = await fetch("/api/claude", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 2000,
          system: FEEDBACK_PROMPT,
          messages: [{
            role: "user",
            content: `Hier ist das Gesprächstranskript eines WITY-Discovery-Gesprächs.\n\nPersona: ${persona.name}, ${persona.role}, ${persona.company}\nHidden Pain der Persona: ${persona.hiddenPain}\n\n--- TRANSKRIPT ---\n${transcript}\n--- ENDE ---\n\nBitte analysiere und gib dein Feedback als JSON.`
          }]
        })
      });
      const data = await res.json();
      const raw = data.content?.map(c => c.text || "").join("") || "";
      const clean = raw.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setFeedback(parsed);
    } catch (e) {
      setFeedback({ error: true, message: "Feedback konnte nicht generiert werden. Bitte versuche es erneut." });
    }
    setFeedbackLoading(false);
  }

  // ===== SCREENS =====

  if (screen === "select") {
    return (
      <div style={{ minHeight: "100vh", background: "#FAFAF8", fontFamily: "'DM Sans', system-ui, sans-serif" }}>
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,wght@0,400;0,500;0,700&family=DM+Mono:wght@400;500&family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,600;0,9..144,700;1,9..144,300&display=swap" rel="stylesheet" />

        <div style={{ maxWidth: 900, margin: "0 auto", padding: "40px 24px" }}>
          {/* Header */}
          <div style={{ marginBottom: 48 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
              <div style={{ width: 32, height: 4, background: "#2E7D32", borderRadius: 2 }} />
              <span style={{ fontSize: 12, fontWeight: 700, letterSpacing: 2, color: "#2E7D32", textTransform: "uppercase", fontFamily: "'DM Mono', monospace" }}>WITY Discovery Training</span>
            </div>
            <h1 style={{ fontSize: 38, fontWeight: 700, color: "#1B1B1B", margin: "8px 0 12px", fontFamily: "'Fraunces', serif", lineHeight: 1.15 }}>
              KI-Sparringspartner
            </h1>
            <p style={{ fontSize: 16, color: "#666", lineHeight: 1.6, maxWidth: 600 }}>
              Trainiere dein WITY-Discovery-Gespräch gegen realistische Schweizer Buyer Personas. Wähle eine Persona und führe das Gespräch – am Ende bekommst du strukturiertes Feedback.
            </p>
          </div>

          {/* Persona Cards */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(380, 1fr))", gap: 16 }}>
            {PERSONAS.map(p => (
              <div key={p.id}
                onClick={() => startConversation(p)}
                style={{
                  background: "#fff", borderRadius: 12, padding: 24, cursor: "pointer",
                  border: "1px solid #E8E8E8", transition: "all 0.2s ease",
                  position: "relative", overflow: "hidden"
                }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = "#2E7D32"; e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.boxShadow = "0 8px 24px rgba(46,125,50,0.1)"; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = "#E8E8E8"; e.currentTarget.style.transform = "none"; e.currentTarget.style.boxShadow = "none"; }}
              >
                <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 3, background: "#2E7D32" }} />

                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 }}>
                  <div>
                    <h3 style={{ fontSize: 18, fontWeight: 700, color: "#1B1B1B", margin: 0, fontFamily: "'Fraunces', serif" }}>{p.name}</h3>
                    <p style={{ fontSize: 13, color: "#888", margin: "2px 0 0" }}>{p.role} · {p.company}</p>
                  </div>
                  <span style={{
                    fontSize: 11, fontWeight: 700, color: "#fff", background: p.diffColor,
                    padding: "3px 10px", borderRadius: 20, letterSpacing: 0.5, fontFamily: "'DM Mono', monospace"
                  }}>{p.difficulty}</span>
                </div>

                <p style={{ fontSize: 14, color: "#555", lineHeight: 1.55, margin: "0 0 14px" }}>
                  {p.context.substring(0, 160)}...
                </p>

                <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                  {p.triggers.map(t => (
                    <span key={t} style={{
                      fontSize: 11, color: "#2E7D32", background: "#E8F5E9",
                      padding: "3px 10px", borderRadius: 20, fontFamily: "'DM Mono', monospace"
                    }}>{t}</span>
                  ))}
                </div>

                <div style={{ marginTop: 16, paddingTop: 14, borderTop: "1px solid #F0F0F0", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <span style={{ fontSize: 13, color: "#2E7D32", fontWeight: 600 }}>Gespräch starten →</span>
                  <span style={{ fontSize: 12, color: "#AAA" }}>{p.industry}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Footer hint */}
          <div style={{ marginTop: 40, padding: "16px 20px", background: "#F0F7F0", borderRadius: 8, borderLeft: "3px solid #2E7D32" }}>
            <p style={{ fontSize: 13, color: "#555", margin: 0, lineHeight: 1.6 }}>
              <strong style={{ color: "#2E7D32" }}>Tipp:</strong> Führe das Gespräch wie einen echten Discovery-Call. Folge dem WITY-Framework: Öffnung → Pain → Vision → Next Step. Die KI reagiert realistisch – zu frühes Pitching wird bestraft, gute Fragen werden belohnt.
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (screen === "feedback") {
    return (
      <div style={{ minHeight: "100vh", background: "#FAFAF8", fontFamily: "'DM Sans', system-ui, sans-serif" }}>
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,wght@0,400;0,500;0,700&family=DM+Mono:wght@400;500&family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,600;0,9..144,700;1,9..144,300&display=swap" rel="stylesheet" />

        <div style={{ maxWidth: 800, margin: "0 auto", padding: "40px 24px" }}>
          <button onClick={() => { setScreen("select"); setFeedback(null); }}
            style={{ background: "none", border: "none", color: "#2E7D32", fontSize: 14, fontWeight: 600, cursor: "pointer", padding: 0, marginBottom: 24, fontFamily: "'DM Sans', sans-serif" }}>
            ← Zurück zur Persona-Auswahl
          </button>

          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
            <div style={{ width: 32, height: 4, background: "#2E7D32", borderRadius: 2 }} />
            <span style={{ fontSize: 12, fontWeight: 700, letterSpacing: 2, color: "#2E7D32", textTransform: "uppercase", fontFamily: "'DM Mono', monospace" }}>Auswertung</span>
          </div>
          <h1 style={{ fontSize: 32, fontWeight: 700, color: "#1B1B1B", margin: "8px 0 6px", fontFamily: "'Fraunces', serif" }}>
            Dein WITY-Feedback
          </h1>
          <p style={{ fontSize: 14, color: "#888", margin: "0 0 32px" }}>
            Gespräch mit {persona?.name}, {persona?.role} · {turnCount} Gesprächsrunden
          </p>

          {feedbackLoading && (
            <div style={{ textAlign: "center", padding: 80 }}>
              <div style={{ width: 40, height: 40, border: "3px solid #E8F5E9", borderTopColor: "#2E7D32", borderRadius: "50%", animation: "spin 0.8s linear infinite", margin: "0 auto 16px" }} />
              <p style={{ color: "#666", fontSize: 15 }}>Gespräch wird analysiert...</p>
              <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
            </div>
          )}

          {feedback?.error && (
            <div style={{ background: "#FFF3F3", border: "1px solid #FFCDD2", borderRadius: 8, padding: 20 }}>
              <p style={{ color: "#D32F2F", margin: 0 }}>{feedback.message}</p>
            </div>
          )}

          {feedback && !feedback.error && (
            <>
              {/* Overall Score */}
              <div style={{ background: "#fff", borderRadius: 12, padding: 28, border: "1px solid #E8E8E8", marginBottom: 20 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 20, marginBottom: 16 }}>
                  <div style={{
                    width: 64, height: 64, borderRadius: "50%",
                    background: feedback.gesamtnote >= 4 ? "#E8F5E9" : feedback.gesamtnote >= 3 ? "#FFF8E1" : "#FFEBEE",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    border: `3px solid ${feedback.gesamtnote >= 4 ? "#2E7D32" : feedback.gesamtnote >= 3 ? "#FF8F00" : "#D32F2F"}`
                  }}>
                    <span style={{
                      fontSize: 28, fontWeight: 700, fontFamily: "'DM Mono', monospace",
                      color: feedback.gesamtnote >= 4 ? "#2E7D32" : feedback.gesamtnote >= 3 ? "#FF8F00" : "#D32F2F"
                    }}>{feedback.gesamtnote}</span>
                  </div>
                  <div>
                    <h2 style={{ fontSize: 20, fontWeight: 700, margin: 0, fontFamily: "'Fraunces', serif", color: "#1B1B1B" }}>Gesamtbewertung</h2>
                    <p style={{ fontSize: 14, color: "#666", margin: "4px 0 0", lineHeight: 1.5 }}>{feedback.zusammenfassung}</p>
                  </div>
                </div>
              </div>

              {/* Categories */}
              <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 20 }}>
                {feedback.kategorien?.map((k, i) => (
                  <div key={i} style={{ background: "#fff", borderRadius: 10, padding: 20, border: "1px solid #E8E8E8" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                      <h3 style={{ fontSize: 15, fontWeight: 700, color: "#1B1B1B", margin: 0 }}>{k.name}</h3>
                    </div>
                    <ScoreBar score={k.score} />
                    <p style={{ fontSize: 13, color: "#555", margin: "10px 0 0", lineHeight: 1.55 }}>{k.feedback}</p>
                    {k.beispiel && (
                      <div style={{ marginTop: 8, padding: "8px 12px", background: "#F8F8F6", borderRadius: 6, borderLeft: "2px solid #CCC" }}>
                        <p style={{ fontSize: 12, color: "#777", margin: 0, fontStyle: "italic" }}>{k.beispiel}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Hidden Pain */}
              <div style={{
                background: feedback.hiddenPainEntdeckt ? "#E8F5E9" : "#FFF8E1",
                borderRadius: 10, padding: 20, marginBottom: 20,
                border: `1px solid ${feedback.hiddenPainEntdeckt ? "#C8E6C9" : "#FFE0B2"}`
              }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                  <span style={{ fontSize: 18 }}>{feedback.hiddenPainEntdeckt ? "✅" : "⚠️"}</span>
                  <h3 style={{ fontSize: 15, fontWeight: 700, margin: 0, color: feedback.hiddenPainEntdeckt ? "#2E7D32" : "#E65100" }}>
                    Hidden Pain {feedback.hiddenPainEntdeckt ? "entdeckt!" : "nicht entdeckt"}
                  </h3>
                </div>
                <p style={{ fontSize: 13, color: "#555", margin: 0, lineHeight: 1.55 }}>{feedback.hiddenPainKommentar}</p>
                {!feedback.hiddenPainEntdeckt && (
                  <p style={{ fontSize: 13, color: "#888", margin: "8px 0 0", fontStyle: "italic" }}>
                    Hidden Pain der Persona: {persona?.hiddenPain}
                  </p>
                )}
              </div>

              {/* Top Tipp */}
              <div style={{ background: "#fff", borderRadius: 10, padding: 20, border: "2px solid #2E7D32" }}>
                <h3 style={{ fontSize: 14, fontWeight: 700, color: "#2E7D32", margin: "0 0 8px", fontFamily: "'DM Mono', monospace", letterSpacing: 1 }}>WICHTIGSTER TIPP</h3>
                <p style={{ fontSize: 15, color: "#1B1B1B", margin: 0, lineHeight: 1.55, fontWeight: 500 }}>{feedback.topTipp}</p>
              </div>

              {/* Actions */}
              <div style={{ display: "flex", gap: 12, marginTop: 28 }}>
                <button onClick={() => startConversation(persona)}
                  style={{ flex: 1, padding: "14px 20px", background: "#2E7D32", color: "#fff", border: "none", borderRadius: 8, fontSize: 14, fontWeight: 600, cursor: "pointer", fontFamily: "'DM Sans', sans-serif" }}>
                  Nochmal mit {persona?.name?.split(" ")[0]} üben
                </button>
                <button onClick={() => { setScreen("select"); setFeedback(null); }}
                  style={{ flex: 1, padding: "14px 20px", background: "#fff", color: "#2E7D32", border: "2px solid #2E7D32", borderRadius: 8, fontSize: 14, fontWeight: 600, cursor: "pointer", fontFamily: "'DM Sans', sans-serif" }}>
                  Andere Persona wählen
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    );
  }

  // ===== CHAT SCREEN =====
  return (
    <div style={{ height: "100vh", display: "flex", flexDirection: "column", background: "#FAFAF8", fontFamily: "'DM Sans', system-ui, sans-serif" }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,wght@0,400;0,500;0,700&family=DM+Mono:wght@400;500&family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,600;0,9..144,700;1,9..144,300&display=swap" rel="stylesheet" />

      {/* Chat Header */}
      <div style={{ background: "#fff", borderBottom: "1px solid #E8E8E8", padding: "14px 20px", display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <button onClick={() => setScreen("select")} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 18, color: "#888", padding: 0, lineHeight: 1 }}>←</button>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <h2 style={{ fontSize: 16, fontWeight: 700, color: "#1B1B1B", margin: 0 }}>{persona?.name}</h2>
              <span style={{ fontSize: 10, fontWeight: 700, color: "#fff", background: persona?.diffColor, padding: "2px 8px", borderRadius: 10, fontFamily: "'DM Mono', monospace" }}>{persona?.difficulty}</span>
            </div>
            <p style={{ fontSize: 12, color: "#888", margin: 0 }}>{persona?.role} · {persona?.company}</p>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ fontSize: 12, color: "#AAA", fontFamily: "'DM Mono', monospace" }}>Runde {turnCount}/12</span>
          {turnCount >= 3 && (
            <button onClick={requestFeedback}
              style={{
                padding: "8px 16px", background: "#2E7D32", color: "#fff", border: "none",
                borderRadius: 6, fontSize: 13, fontWeight: 600, cursor: "pointer", fontFamily: "'DM Sans', sans-serif"
              }}>
              Feedback anfordern
            </button>
          )}
        </div>
      </div>

      {/* Chat Messages */}
      <div style={{ flex: 1, overflow: "auto", padding: "20px 20px 8px" }}>
        {/* WITY reminder */}
        <div style={{ background: "#F0F7F0", borderRadius: 8, padding: "10px 14px", marginBottom: 20, display: "flex", gap: 10, alignItems: "flex-start" }}>
          <span style={{ fontSize: 14, flexShrink: 0 }}>💡</span>
          <p style={{ fontSize: 12, color: "#555", margin: 0, lineHeight: 1.5 }}>
            <strong>WITY-Framework:</strong> Öffnung (Was hat sich verändert?) → Pain (Wo kostet Integration Zeit/Geld?) → Vision (Was müsste in 12 Monaten anders sein?) → Next Step (Konkreter Folgetermin)
          </p>
        </div>

        {messages.map((m, i) => (
          <div key={i} style={{ display: "flex", justifyContent: m.role === "seller" ? "flex-end" : "flex-start", marginBottom: 12 }}>
            <div style={{
              maxWidth: "75%", padding: "12px 16px", borderRadius: 14,
              background: m.role === "seller" ? "#2E7D32" : "#fff",
              color: m.role === "seller" ? "#fff" : "#1B1B1B",
              border: m.role === "persona" ? "1px solid #E8E8E8" : "none",
              boxShadow: m.role === "persona" ? "0 1px 3px rgba(0,0,0,0.04)" : "none"
            }}>
              {m.role === "persona" && (
                <p style={{ fontSize: 11, fontWeight: 700, color: "#2E7D32", margin: "0 0 4px", fontFamily: "'DM Mono', monospace" }}>{persona?.name}</p>
              )}
              <p style={{ fontSize: 14, margin: 0, lineHeight: 1.55, whiteSpace: "pre-wrap" }}>{m.text}</p>
            </div>
          </div>
        ))}

        {loading && (
          <div style={{ display: "flex", justifyContent: "flex-start", marginBottom: 12 }}>
            <div style={{ background: "#fff", border: "1px solid #E8E8E8", borderRadius: 14, padding: "12px 20px" }}>
              <div style={{ display: "flex", gap: 5 }}>
                {[0, 1, 2].map(j => (
                  <div key={j} style={{
                    width: 7, height: 7, borderRadius: "50%", background: "#CCC",
                    animation: `pulse 1s ease-in-out ${j * 0.15}s infinite`
                  }} />
                ))}
              </div>
              <style>{`@keyframes pulse { 0%,100% { opacity: 0.3 } 50% { opacity: 1 } }`}</style>
            </div>
          </div>
        )}

        {error && (
          <div style={{ background: "#FFEBEE", borderRadius: 8, padding: "10px 14px", marginBottom: 12 }}>
            <p style={{ fontSize: 13, color: "#D32F2F", margin: 0 }}>{error}</p>
          </div>
        )}

        <div ref={chatEndRef} />
      </div>

      {/* Input */}
      <div style={{ background: "#fff", borderTop: "1px solid #E8E8E8", padding: "12px 16px", flexShrink: 0 }}>
        <div style={{ display: "flex", gap: 10, maxWidth: 800, margin: "0 auto" }}>
          <input ref={inputRef} value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
            placeholder="Deine Nachricht als Seller..."
            disabled={loading}
            style={{
              flex: 1, padding: "12px 16px", borderRadius: 10, border: "1px solid #DDD",
              fontSize: 14, outline: "none", fontFamily: "'DM Sans', sans-serif",
              background: loading ? "#F5F5F5" : "#fff"
            }}
          />
          <button onClick={sendMessage} disabled={loading || !input.trim()}
            style={{
              padding: "12px 20px", background: loading || !input.trim() ? "#CCC" : "#2E7D32",
              color: "#fff", border: "none", borderRadius: 10, fontSize: 14,
              fontWeight: 600, cursor: loading || !input.trim() ? "default" : "pointer",
              fontFamily: "'DM Sans', sans-serif", flexShrink: 0
            }}>
            Senden
          </button>
        </div>
        <div style={{ display: "flex", justifyContent: "center", gap: 16, marginTop: 8 }}>
          {turnCount >= 3 && (
            <button onClick={requestFeedback}
              style={{ background: "none", border: "none", color: "#2E7D32", fontSize: 12, fontWeight: 600, cursor: "pointer", fontFamily: "'DM Sans', sans-serif" }}>
              📊 Gespräch beenden & Feedback
            </button>
          )}
          <button onClick={() => startConversation(persona)}
            style={{ background: "none", border: "none", color: "#999", fontSize: 12, cursor: "pointer", fontFamily: "'DM Sans', sans-serif" }}>
            ↺ Neu starten
          </button>
        </div>
      </div>
    </div>
  );
}
