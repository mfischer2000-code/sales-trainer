import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import WITYTrainer from './App.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <WITYTrainer />
  </StrictMode>,
)
